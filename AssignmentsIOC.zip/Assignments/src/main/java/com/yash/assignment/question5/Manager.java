package com.yash.assignment.question5;

public class Manager extends Employee{

	@Override
	public void empDetails() {
		// TODO Auto-generated method stub
		System.out.println("Employee role is Manager");
	}

	
}
