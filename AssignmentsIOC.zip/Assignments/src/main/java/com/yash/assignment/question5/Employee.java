package com.yash.assignment.question5;

public abstract class Employee 
{		
	abstract void empDetails();

}
