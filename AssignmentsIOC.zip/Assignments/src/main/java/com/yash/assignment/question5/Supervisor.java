package com.yash.assignment.question5;

public class Supervisor extends Employee
{
	@Override
	public void empDetails() 
	{
		System.out.println("Employee role is Supervisor");
		
	}

}
