package com.yash.assignment.question2;

public class ShapeFactory {

	public Shape getRectangle() {
		
		return new Rectangle();
	}
}
