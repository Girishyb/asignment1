package com.yash.assignment.question5;


public class EmployeeFactory {

	 public static Employee getEmployeeObj()
	  {
		 return new Clerk(); 
	  }

}
