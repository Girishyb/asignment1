package com.yash.assignment.question5;

public class Clerk extends Employee{

	@Override
	public void empDetails() {
		System.out.println("Employee role is clerk");
	}

}
