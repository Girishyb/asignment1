package com.yash.assignment.question2;

public abstract class Shape 
{
	abstract void draw();
	
}
