package com.yash.assignment.question2;

public class Parallelogram extends Shape{

	@Override
	void draw() {
		System.out.println("This is Rectangle");
	}

	

}
