package com.yash.assignment.question2;

public class Rectangle extends Shape {

	
	@Override
	void draw() {
		
		System.out.println("This is Rectangle");
		
	}

	

	
}
